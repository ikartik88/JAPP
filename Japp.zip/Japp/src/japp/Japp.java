/*package japp;

import javax.swing.JFrame;

public class Japp {

    public static void main(String[] args) {
        Jinterface ji=new Jinterface();
        ji.setVisible(true);
        ji.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
*/
