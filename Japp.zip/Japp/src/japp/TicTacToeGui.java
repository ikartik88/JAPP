package japp;


import java.awt.Color;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kartikeya
 */
public class TicTacToeGui extends javax.swing.JFrame 
{
private String startGame="X";
private int xCount=0;
private int oCount=0;
int x=0;
    
    /**
     * Creates new form TicTacToeGui
     */
    public TicTacToeGui() 
    {
        initComponents();
        setSize(779,499);
        setLocationRelativeTo(null);
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("images (9).jpeg")));
    }
    private void gameScore()
    {
      jbtn5.setText(String.valueOf(xCount));
      jbtn10.setText(String.valueOf(oCount));
    }
    
    private void choose_A_Player()
    {
        if(startGame.equalsIgnoreCase("X"))
        {
            startGame="O";
        }
        else
        {
            startGame="X";
        }
    }
    private void winningGame()
    {
        String b1=jbtn1.getText();
        String b2=jbtn2.getText();
        String b3=jbtn3.getText();
        
        String b4=jbtn6.getText();
        String b5=jbtn7.getText();
        String b6=jbtn8.getText();
        
        String b7=jbtn11.getText();
        String b8=jbtn12.getText();
        String b9=jbtn13.getText();
        if(b1==("X")&&b2==("X")&&b3==("X"))
        {
            JOptionPane.showMessageDialog(this,"Player X wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jbtn1.setBackground(Color.YELLOW);
            jbtn2.setBackground(Color.YELLOW);
            jbtn3.setBackground(Color.YELLOW);
            
        }
        else if(b1==("O")&&b2==("O")&&b3==("O"))
        {
            JOptionPane.showMessageDialog(this,"Player O wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            oCount++;
            gameScore();
            jbtn1.setBackground(Color.YELLOW);
            jbtn2.setBackground(Color.YELLOW);
            jbtn3.setBackground(Color.YELLOW);
            
        }
       
          if(b7==("X")&&b8==("X")&&b9==("X"))
        {
            JOptionPane.showMessageDialog(this,"Player X wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jbtn7.setBackground(Color.YELLOW);
            jbtn8.setBackground(Color.YELLOW);
            jbtn9.setBackground(Color.YELLOW);
            
        }
          else if(b7==("O")&&b8==("O")&&b9==("O"))
        {
            JOptionPane.showMessageDialog(this,"Player O wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            oCount++;
            gameScore();
            jbtn7.setBackground(Color.YELLOW);
            jbtn8.setBackground(Color.YELLOW);
            jbtn9.setBackground(Color.YELLOW);
            
        }
           if(b1==("X")&&b4==("X")&&b7==("X"))
        {
            JOptionPane.showMessageDialog(this,"Player X wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jbtn1.setBackground(Color.MAGENTA);
            jbtn6.setBackground(Color.MAGENTA);
            jbtn11.setBackground(Color.MAGENTA);
            
        }
            else if(b1==("O")&&b4==("O")&&b7==("O"))
        {
            JOptionPane.showMessageDialog(this,"Player O wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            oCount++;
            gameScore();
            jbtn1.setBackground(Color.MAGENTA);
            jbtn6.setBackground(Color.MAGENTA);
            jbtn11.setBackground(Color.MAGENTA);
            
        }
            if(b2==("X")&&b5==("X")&&b8==("X"))
        {
            JOptionPane.showMessageDialog(this,"Player X wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jbtn2.setBackground(Color.PINK);
            jbtn7.setBackground(Color.PINK);
            jbtn12.setBackground(Color.PINK);
            
        }
            else if(b2==("O")&&b5==("O")&&b8==("O"))
        {
            JOptionPane.showMessageDialog(this,"Player O wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            oCount++;
            gameScore();
            jbtn2.setBackground(Color.PINK);
            jbtn7.setBackground(Color.PINK);
            jbtn12.setBackground(Color.PINK);
            
        }
           if(b3==("X")&&b6==("X")&&b9==("X"))
        {
            JOptionPane.showMessageDialog(this,"Player X wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jbtn3.setBackground(Color.BLUE);
            jbtn8.setBackground(Color.BLUE);
            jbtn13.setBackground(Color.BLUE);
            
        }   
           else if(b3==("O")&&b6==("O")&&b9==("O"))
        {
            JOptionPane.showMessageDialog(this,"Player O wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            oCount++;
            gameScore();
            jbtn3.setBackground(Color.lightGray);
            jbtn8.setBackground(Color.lightGray);
            jbtn13.setBackground(Color.lightGray);
            
        }   
              if(b1==("X")&&b5==("X")&&b9==("X"))
        {
            JOptionPane.showMessageDialog(this,"Player X wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jbtn1.setBackground(Color.white);
            jbtn7.setBackground(Color.white);
            jbtn13.setBackground(Color.white);
            
        }
          else if(b1==("O")&&b5==("O")&&b9==("O"))
        {
            JOptionPane.showMessageDialog(this,"Player O wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            oCount++;
            gameScore();
            jbtn1.setBackground(Color.ORANGE);
            jbtn7.setBackground(Color.ORANGE);
            jbtn13.setBackground(Color.ORANGE);
            
        }
                 if(b3==("X")&&b5==("X")&&b7==("X"))
        {
            JOptionPane.showMessageDialog(this,"Player X wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jbtn3.setBackground(Color.CYAN);
            jbtn7.setBackground(Color.CYAN);
            jbtn11.setBackground(Color.CYAN);
            
        }
          else if(b3==("O")&&b5==("O")&&b7==("O"))
        {
            JOptionPane.showMessageDialog(this,"Player O wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            oCount++;
            gameScore();
            jbtn3.setBackground(Color.CYAN);
            jbtn7.setBackground(Color.CYAN);
            jbtn11.setBackground(Color.CYAN);
            
        }
             if(b4==("X")&&b5==("X")&&b6==("X")){
                  JOptionPane.showMessageDialog(this,"Player X wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jbtn6.setBackground(Color.CYAN);
            jbtn7.setBackground(Color.CYAN);
            jbtn8.setBackground(Color.CYAN);
                 
             }
             else if(b4==("O")&&b5==("O")&&b6==("O")){
                  JOptionPane.showMessageDialog(this,"Player O wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jbtn6.setBackground(Color.CYAN);
            jbtn7.setBackground(Color.CYAN);
            jbtn8.setBackground(Color.CYAN);
             }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jbtn1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jbtn2 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jbtn3 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jbtn4 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jbtn5 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jbtn6 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jbtn7 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jbtn8 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jbtn9 = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jbtn10 = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jbtn11 = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        jbtn12 = new javax.swing.JButton();
        jPanel14 = new javax.swing.JPanel();
        jbtn13 = new javax.swing.JButton();
        jPanel15 = new javax.swing.JPanel();
        jbtn14 = new javax.swing.JButton();
        jPanel16 = new javax.swing.JPanel();
        jbtn15 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("TicTac Toe");

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel1.setLayout(new java.awt.GridLayout(3, 5, 2, 2));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new java.awt.BorderLayout());

        jbtn1.setBackground(new java.awt.Color(0, 0, 0));
        jbtn1.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jbtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn1ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn1, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel2);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new java.awt.BorderLayout());

        jbtn2.setBackground(new java.awt.Color(0, 0, 0));
        jbtn2.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jbtn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn2ActionPerformed(evt);
            }
        });
        jPanel3.add(jbtn2, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel3);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new java.awt.BorderLayout());

        jbtn3.setBackground(new java.awt.Color(0, 0, 0));
        jbtn3.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jbtn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn3ActionPerformed(evt);
            }
        });
        jPanel4.add(jbtn3, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel4);

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setLayout(new java.awt.BorderLayout());

        jbtn4.setBackground(new java.awt.Color(153, 153, 153));
        jbtn4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jbtn4.setForeground(new java.awt.Color(255, 255, 255));
        jbtn4.setText("Player X:");
        jPanel5.add(jbtn4, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel5);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setLayout(new java.awt.BorderLayout());

        jbtn5.setBackground(new java.awt.Color(255, 255, 255));
        jbtn5.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jPanel6.add(jbtn5, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel6);

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setLayout(new java.awt.BorderLayout());

        jbtn6.setBackground(new java.awt.Color(0, 0, 0));
        jbtn6.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jbtn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn6ActionPerformed(evt);
            }
        });
        jPanel8.add(jbtn6, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel8);

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setLayout(new java.awt.BorderLayout());

        jbtn7.setBackground(new java.awt.Color(0, 0, 0));
        jbtn7.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jbtn7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn7ActionPerformed(evt);
            }
        });
        jPanel7.add(jbtn7, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel7);

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setLayout(new java.awt.BorderLayout());

        jbtn8.setBackground(new java.awt.Color(0, 0, 0));
        jbtn8.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jbtn8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn8ActionPerformed(evt);
            }
        });
        jPanel9.add(jbtn8, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel9);

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setLayout(new java.awt.BorderLayout());

        jbtn9.setBackground(new java.awt.Color(153, 153, 153));
        jbtn9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jbtn9.setForeground(new java.awt.Color(255, 255, 255));
        jbtn9.setText("Player O:");
        jPanel10.add(jbtn9, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel10);

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setLayout(new java.awt.BorderLayout());

        jbtn10.setBackground(new java.awt.Color(255, 255, 255));
        jbtn10.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jPanel11.add(jbtn10, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel11);

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));
        jPanel12.setLayout(new java.awt.BorderLayout());

        jbtn11.setBackground(new java.awt.Color(0, 0, 0));
        jbtn11.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jbtn11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn11ActionPerformed(evt);
            }
        });
        jPanel12.add(jbtn11, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel12);

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));
        jPanel13.setLayout(new java.awt.BorderLayout());

        jbtn12.setBackground(new java.awt.Color(0, 0, 0));
        jbtn12.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jbtn12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn12ActionPerformed(evt);
            }
        });
        jPanel13.add(jbtn12, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel13);

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));
        jPanel14.setLayout(new java.awt.BorderLayout());

        jbtn13.setBackground(new java.awt.Color(0, 0, 0));
        jbtn13.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jbtn13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn13ActionPerformed(evt);
            }
        });
        jPanel14.add(jbtn13, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel14);

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));
        jPanel15.setLayout(new java.awt.BorderLayout());

        jbtn14.setBackground(new java.awt.Color(204, 255, 255));
        jbtn14.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jbtn14.setText("Reset");
        jbtn14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn14ActionPerformed(evt);
            }
        });
        jPanel15.add(jbtn14, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel15);

        jPanel16.setBackground(new java.awt.Color(255, 255, 255));
        jPanel16.setLayout(new java.awt.BorderLayout());

        jbtn15.setBackground(new java.awt.Color(255, 204, 204));
        jbtn15.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jbtn15.setText("Exit");
        jbtn15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn15ActionPerformed(evt);
            }
        });
        jPanel16.add(jbtn15, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel16);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents
private JFrame frame;
    private void jbtn15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn15ActionPerformed
        // TODO add your handling code here:
        frame=new JFrame("Exit");
        if(JOptionPane.showConfirmDialog(frame," Confirm if you want to exit","Tic Tac Toe", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION)
         System.exit(0);   
    }//GEN-LAST:event_jbtn15ActionPerformed

    private void jbtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn1ActionPerformed
        // TODO add your handling code here:
      
        jbtn1.setText(startGame);
        if(startGame.equalsIgnoreCase("X"))
        {
            jbtn1.setForeground(Color.GREEN);
            
        }
        else
        {
            jbtn1.setForeground(Color.BLUE);
        }
        jbtn1.setEnabled(false);
        choose_A_Player();
        winningGame();
    }//GEN-LAST:event_jbtn1ActionPerformed

    private void jbtn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn2ActionPerformed
        // TODO add your handling code here:
        jbtn2.setText(startGame);
        //jbtn2.set(false);
        if(startGame.equalsIgnoreCase("X"))
        {
            jbtn2.setForeground(Color.GREEN);
        }
        else
        {
            jbtn2.setForeground(Color.BLUE);
        }
        jbtn2.setEnabled(false);
        choose_A_Player();
        winningGame();
    }//GEN-LAST:event_jbtn2ActionPerformed

    private void jbtn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn3ActionPerformed
        // TODO add your handling code here:
        jbtn3.setText(startGame);
        if(startGame.equalsIgnoreCase("X"))
        {
            jbtn3.setForeground(Color.GREEN);
        }
        else
        {
            jbtn3.setForeground(Color.BLUE);
        }
         jbtn3.setEnabled(false);
        choose_A_Player();
        winningGame();
    }//GEN-LAST:event_jbtn3ActionPerformed

    private void jbtn6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn6ActionPerformed
        // TODO add your handling code here:
        jbtn6.setText(startGame);
        if(startGame.equalsIgnoreCase("X"))
        {
            jbtn6.setForeground(Color.GREEN);
        }
        else
        {
            jbtn6.setForeground(Color.BLUE);
        }
         jbtn6.setEnabled(false);
        choose_A_Player();
        winningGame();
    }//GEN-LAST:event_jbtn6ActionPerformed

    private void jbtn7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn7ActionPerformed
        // TODO add your handling code here:
        jbtn7.setText(startGame);
        if(startGame.equalsIgnoreCase("x"))
        {
            jbtn7.setForeground(Color.GREEN);
        }
        else
        {
            jbtn7.setForeground(Color.BLUE);
        }
         jbtn7.setEnabled(false);
        choose_A_Player();
        winningGame();
    }//GEN-LAST:event_jbtn7ActionPerformed

    private void jbtn8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn8ActionPerformed
        // TODO add your handling code here:
        jbtn8.setText(startGame);
        if(startGame.equalsIgnoreCase("X"))
        {
            jbtn8.setForeground(Color.GREEN);
        }
        else
        {
            jbtn8.setForeground(Color.BLUE);
        }
         jbtn8.setEnabled(false);
        choose_A_Player();
        winningGame();
        
    }//GEN-LAST:event_jbtn8ActionPerformed

    private void jbtn11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn11ActionPerformed
        // TODO add your handling code here:
        jbtn11.setText(startGame);
        if(startGame.equalsIgnoreCase("X"))
        {
            jbtn11.setForeground(Color.GREEN);
        }
        else
        {
            jbtn11.setForeground(Color.BLUE);
        }
         jbtn11.setEnabled(false);
        choose_A_Player();
        winningGame();
        
    }//GEN-LAST:event_jbtn11ActionPerformed

    private void jbtn12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn12ActionPerformed
        // TODO add your handling code here:
        jbtn12.setText(startGame);
        if(startGame.equalsIgnoreCase(startGame))
        {
            jbtn12.setForeground(Color.GREEN);
        }
        else
        {
            jbtn12.setForeground(Color.BLUE);
        }
         jbtn12.setEnabled(false);
        choose_A_Player();
        winningGame();
        
    }//GEN-LAST:event_jbtn12ActionPerformed

    private void jbtn13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn13ActionPerformed
        // TODO add your handling code here:
        jbtn13.setText(startGame);
        if(startGame.equalsIgnoreCase("X"))
        {
            jbtn13.setForeground(Color.GREEN);
        }
        else
        {
            jbtn13.setForeground(Color.BLUE);
        }
         jbtn13.setEnabled(false);
        choose_A_Player();
        winningGame();
        
    }//GEN-LAST:event_jbtn13ActionPerformed

    private void jbtn14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn14ActionPerformed
        // TODO add your handling code here:
        jbtn1.setText(null);
        jbtn2.setText(null);
        jbtn3.setText(null);
        
        jbtn6.setText(null);
        jbtn7.setText(null);
        jbtn8.setText(null);
        
        jbtn11.setText(null);
        jbtn12.setText(null);
        jbtn13.setText(null);
        
        jbtn1.setEnabled(true);
        jbtn2.setEnabled(true);
        jbtn3.setEnabled(true);
        jbtn6.setEnabled(true);
        jbtn7.setEnabled(true);
        jbtn8.setEnabled(true);
        jbtn11.setEnabled(true);
        jbtn12.setEnabled(true);
        jbtn13.setEnabled(true);
        
        jbtn1.setBackground(Color.BLACK);
        jbtn2.setBackground(Color.BLACK);
        jbtn3.setBackground(Color.BLACK);
        
        jbtn6.setBackground(Color.BLACK);
        jbtn7.setBackground(Color.BLACK);
        jbtn8.setBackground(Color.BLACK);
        
        jbtn11.setBackground(Color.BLACK);
        jbtn12.setBackground(Color.BLACK);
        jbtn13.setBackground(Color.BLACK);
    }//GEN-LAST:event_jbtn14ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TicTacToeGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TicTacToeGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TicTacToeGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TicTacToeGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TicTacToeGui().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JButton jbtn1;
    private javax.swing.JButton jbtn10;
    private javax.swing.JButton jbtn11;
    private javax.swing.JButton jbtn12;
    private javax.swing.JButton jbtn13;
    private javax.swing.JButton jbtn14;
    private javax.swing.JButton jbtn15;
    private javax.swing.JButton jbtn2;
    private javax.swing.JButton jbtn3;
    private javax.swing.JButton jbtn4;
    private javax.swing.JButton jbtn5;
    private javax.swing.JButton jbtn6;
    private javax.swing.JButton jbtn7;
    private javax.swing.JButton jbtn8;
    private javax.swing.JButton jbtn9;
    // End of variables declaration//GEN-END:variables
}
