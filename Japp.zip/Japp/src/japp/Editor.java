package japp;

import javax.swing.JFrame;

/**
 *
 * @author kartikeya
 */
public class Editor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
    Notes n=new Notes();
    n.setTitle("Notepad");
    n.setResizable(true); 
    n.setVisible(true);
    n.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
